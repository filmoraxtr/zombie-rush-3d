Zombie Rush 3D — v2.0 THREE.JS GERÇEK 3D SÜRÜM
================================================

YENİLİKLER (v2.0):
- Oyun tamamen Three.js ile GERÇEK 3D olarak yeniden yazıldı
- Birinci şahıs (FPS) kamera — silah elinde görünüyor
- Gece atmosferi: ay, yıldızlar, sis, yeşil toksik duman
- 3D zombiler: yürüme animasyonu, kırmızı gözler, can barı
- 3D yol, çimen, ağaçlar, elektrik direkleri, tel çit
- Namlu alevi (muzzle flash) ve ateş efektleri
- Mermi sayacı (şarjör sistemi) — mermi bitince otomatik yenilenir
- Zombi ölünce yeşil parçacık patlaması
- Coin toplama, market ve envanter sistemi korundu
- Kayıtlar localStorage'da saklanıyor (coin, rekor, silahlar)

KONTROLLER:
- ◀ / ▶ : Şerit değiştir (3 şerit)
- ATEŞ 🔥 : Basılı tut, sürekli ateş eder
- Klavye: Ok tuşları + Boşluk (PC'de test için)

ÖNEMLİ NOT:
- Oyun Three.js kütüphanesini internetten (CDN) yüklüyor.
- İlk açılışta TELEFONUN İNTERNETE BAĞLI OLMASI GEREKİR.
- (İstersen bir sonraki sürümde three.min.js dosyasını
  assets klasörüne gömerek tamamen çevrimdışı yapabiliriz.)

APK NASIL ALINIR (GitHub Actions):
1. Bu klasörü GitHub'a yeni bir repo olarak yükle
2. Actions sekmesi otomatik çalışır
3. Build bitince "ZombieRush3D-v2-3D-debug-apk" artifact'ını indir
4. İçindeki app-debug.apk dosyasını telefonuna kur
