Zombie Rush 3D — v3.0 GERÇEKÇİ GRAFİK & SES SÜRÜMÜ
====================================================
(Into the Dead 2 referans alınarak güncellendi)

v3.0 YENİLİKLERİ:
- PAUSE MENÜSÜ: Duraklatınca Devam Et / Yeniden Başla / Ana Menü
- GERÇEKÇİ SİLAH SESLERİ: Web Audio ile sentezlenen patlama + gümleme
  + yankı kuyruğu + sürgü kliki. Her silahın sesi farklı:
  Pistol keskin, Uzi cırtlak, Shotgun gümbürtülü, Rifle tok.
- Zombi vurulma (ıslak darbe), ölüm hırıltısı, hasar ve coin sesleri
- GERÇEKÇİ SİLAH MODELİ: sürgü, namlu, kabza, tetik korkuluğu,
  nişangahlar + silahı kavrayan İKİ EL ve kollar (FPS görünüm)
- Ateş edince geri tepme animasyonu + sürgü hareketi + namlu alevi ışığı
- GERÇEKÇİ ZOMBİLER: kambur duruş, ileri uzanan kollar, yana eğik kafa,
  sarkık çene, kızıl gözler, yırtık kıyafet, kan lekesi,
  5 farklı çürümüş ten tonu, sendeleyerek yürüme animasyonu
- AYDINLATMA: çok daha görünür sahne — güçlü ay ışığı, el feneri
  spotu, sokak lambası titremesi, alçak yer sisi
- Vuruşta kan parçacıkları, ekran kenarı hasar efekti (kırmızı vinyet)
- Performans: ekranda en fazla 14 zombi (eski telefonlar için)

NOT: İlk açılışta internet gerekir (Three.js CDN'den yüklenir).

APK ALMA: Repo'daki ZIP'i bu yenisiyle değiştir, Actions otomatik derler.
