Zombie Rush 3D v3.8 REAL IMAGE WEAPON SPRITE FIX

Bu sürüm, silahın kodla çizilmiş sahte SVG gibi görünmesi sorununu çözer.

Ana değişiklikler:
- v3.7'deki SVG/kart/sticker silah sistemi tamamen kaldırıldı.
- Kullanıcının verdiği gerçek tabanca görselinden şeffaf PNG asset çıkarıldı.
- assets/pistol_ref_transparent.png olarak oyuna eklendi.
- Silah artık gerçek görsel asset olarak sağ alt FPS konumunda durur.
- Arkada turuncu/kırmızı kart yoktur.
- El, parmak ve kol/sleeve katmanı eklenerek silah elde tutuluyormuş hissi verilir.
- Ateş sırasında recoil + muzzle flash gerçek sprite üstünde çalışır.
- Reload sırasında silah aşağı/yana hareket eder.
- Joystick hareketinde sway çalışır.
- Eski Three gun mesh görünmez yapıldı; oyun mantığı korunur.
- v3.7/v3.5 sistemleri korunur:
  - 15 mermi şarjör
  - yedek mermi
  - dry fire
  - reload sesi
  - headshot bonus
  - kill coin
  - horde AI
  - performance cleanup
  - gerçek Three.js CDN

ZIP:
ZombieRush3D_Android_Project_v3_8_REAL_IMAGE_WEAPON_SPRITE_FIX.zip

Artifact:
ZombieRush3D-v3-8-REAL-IMAGE-WEAPON-SPRITE-FIX-debug-apk
