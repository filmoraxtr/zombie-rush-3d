Zombie Rush 3D v3.7 TRUE FPS HANDGUN INTEGRATION

Bu sürüm FPS silah entegrasyonunu düzeltir.

Ana değişiklikler:
- v3.6'daki sticker/kart gibi görünen silah sistemi kaldırıldı.
- Silah artık arka plan kartı olmadan FPS elinde görünecek şekilde yerleştirildi.
- Sağ alt FPS pozisyonu daha doğal ayarlandı.
- El + tabanca birlikte çizildi; silah elde tutuluyormuş hissi verir.
- Mat siyah kompakt 9mm pistol formu korundu.
- Slide, frame, grip, trigger guard, tetik, muzzle, sight ve grip texture detayları vardır.
- Eski Three gun mesh görünmez yapıldı; oyun mantığı korunur.
- Ateş edince recoil + muzzle flash vardır.
- Reload sırasında silah aşağı/yana hareket eder.
- Joystick hareketinde silah sway yapar.
- v3.5 sistemleri korunur:
  - 15 mermi şarjör
  - yedek mermi
  - boş tetik sesi
  - reload sesi
  - headshot bonus
  - kill coin
  - horde AI
  - performance cleanup
  - gerçek Three.js CDN

ZIP:
ZombieRush3D_Android_Project_v3_7_TRUE_FPS_HANDGUN_INTEGRATION.zip

Artifact:
ZombieRush3D-v3-7-TRUE-FPS-HANDGUN-INTEGRATION-debug-apk
