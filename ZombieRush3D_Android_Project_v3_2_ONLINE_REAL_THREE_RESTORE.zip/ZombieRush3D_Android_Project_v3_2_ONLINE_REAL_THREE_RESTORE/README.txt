Zombie Rush 3D v3.2 ONLINE REAL THREE RESTORE

Bu sürüm v3.1'deki kalite düşüşünü düzeltir.

Neden:
- v3.1'de internet bağımlılığını kaldırmak için lightweight/offline three uyumluluk çekirdeği kullanıldı.
- Bu çekirdek gerçek WebGL/Three.js kalitesini veremedi ve sahne soluk/basit göründü.
- Kullanıcı için internetli çalışma sorun olmadığı için gerçek Three.js CDN geri alındı.

Yapılanlar:
- Offline sahte three.min.js kaldırıldı.
- HTML tekrar gerçek Three.js CDN kullanır:
  https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
- Kullanıcının gönderdiği 3D projenin orijinal görsel kalitesi geri getirildi.
- Coin sadece zombi öldürünce gelir.
- Rastgele sahne coin spawn kapalıdır.
- Reload sistemi süreli hale getirildi.
- Silah değişince ammo/reload resetlenir.
- Market ve envanter korunur.
- GitHub Actions workflow hazırdır.

ZIP:
ZombieRush3D_Android_Project_v3_2_ONLINE_REAL_THREE_RESTORE.zip

Artifact:
ZombieRush3D-v3-2-ONLINE-REAL-THREE-RESTORE-debug-apk
