Zombie Rush 3D v3.3 JOYSTICK COMBAT MEGA UPDATE

Ana düzeltmeler:
- Sol/sağ tuşunun oyuncuyu direkt en sola/en sağa atması kaldırıldı.
- Joystick eklendi.
- Oyuncu artık analog ve yumuşak sağ/sol hareket eder.
- Mermi çarpışması lane sistemi yerine gerçek X pozisyonuna göre yapılır.
- Ortadaki zombileri vuramama sorunu giderildi.
- Zombiler artık sırayla düz gitmez; oyuncuya doğru saldırmaya çalışır.
- Zombi hızları yükseltildi.
- Canın azalmaması problemi düzeltildi; zombi yaklaşınca ve temas edince hasar verir.
- Zombi saldırı animasyonu güçlendirildi.
- Vuruş hissi güçlendirildi: kamera shake, kan, knockback, hit animasyon.
- Reload sistemi korunur ve reload butonu eklendi.
- Silah isimleri ve değerleri daha gerçekçi yapıldı.
- Gerçek Three.js CDN korunur; v3.1'deki düşük kalite offline shim kullanılmaz.
- Coin sadece zombi öldürünce kazanılır.

ZIP:
ZombieRush3D_Android_Project_v3_3_JOYSTICK_COMBAT_MEGA_UPDATE.zip

Artifact:
ZombieRush3D-v3-3-JOYSTICK-COMBAT-MEGA-UPDATE-debug-apk
