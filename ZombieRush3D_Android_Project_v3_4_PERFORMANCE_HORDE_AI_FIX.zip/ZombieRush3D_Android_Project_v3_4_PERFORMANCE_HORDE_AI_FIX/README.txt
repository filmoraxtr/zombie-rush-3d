Zombie Rush 3D v3.4 PERFORMANCE HORDE AI FIX

Video analizi sonrası yapılan güncelleme:
- Zombiler ekrana fazla birikip oyunu çökertmesin diye performans limiti eklendi.
- MAX_ZOMBIES 11, TARGET_ZOMBIES 7 olarak dengelendi.
- Akıllı spawn sistemi eklendi: zombiler aynı noktaya yığılmaz, etrafa dağılır.
- Zombiler uzakta dağınık kalır; yaklaşınca oyuncuya doğru saldırmaya çalışır.
- Zombiler eskisi gibi tek hattan gelmez.
- Yakın zombi saldırı animasyonu güçlendirildi.
- Zombi hızları dengelendi; çok yavaş kalmaz ama kontrolsüz birikmez.
- Uzakta/arkada kalan zombiler otomatik temizlenir.
- Fazla mermi/kan partikülü otomatik temizlenir.
- Kan efekti ve hit hissi korunur ama performans için limitle çalışır.
- Oyuncuya temas edince can azaltma daha güvenilir hale getirildi.
- Gerçek Three.js CDN korunur.
- Joystick, reload, kill coin sistemi korunur.

ZIP:
ZombieRush3D_Android_Project_v3_4_PERFORMANCE_HORDE_AI_FIX.zip

Artifact:
ZombieRush3D-v3-4-PERFORMANCE-HORDE-AI-FIX-debug-apk
