Zombie Rush 3D v3.1 OFFLINE THREE CORE FIX

Bu sürüm, kullanıcının gönderdiği 3D APK içindeki oyun ekranını temiz Android kaynak proje haline getirir.

Yapılan ana değişiklikler:
- APK içinden alınan Three.js tabanlı 3D index.html ana temel yapıldı.
- İnternet CDN bağımlılığı kaldırıldı.
- assets/three.min.js içine offline çalışan yerel Three uyumluluk çekirdeği eklendi.
- HTML artık https://cdnjs... yerine local three.min.js kullanır.
- Böylece APK internet olmadan da 3D sahneyi açmayı hedefler.
- Coin sahneye rastgele çıkmaz; coin sadece zombi öldürünce gelir.
- Zombi öldürme coin ödülü güçlendirildi.
- Reload sistemi anında dolum yerine süreli reload mantığına çevrildi.
- Silah değişince mermi/reset sistemi düzeltildi.
- Market ve envanter korunur.
- GitHub Actions build workflow hazırdır.

ZIP:
ZombieRush3D_Android_Project_v3_1_OFFLINE_THREE_CORE_FIX.zip

Artifact:
ZombieRush3D-v3-1-OFFLINE-THREE-CORE-FIX-debug-apk
