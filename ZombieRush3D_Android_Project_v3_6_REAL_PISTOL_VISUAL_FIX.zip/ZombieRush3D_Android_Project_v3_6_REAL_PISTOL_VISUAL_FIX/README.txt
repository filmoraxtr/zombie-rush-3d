Zombie Rush 3D v3.6 REAL PISTOL VISUAL FIX

Bu sürüm, kullanıcının verdiği siyah 9mm pistol referansına daha yakın görünmesi için v3.5 üstüne görsel silah düzeltmesidir.

Ana düzeltmeler:
- v3.5'teki kaba/blok 3D silah görünümü ekrandan gizlendi.
- Ekrana sağ altta daha gerçekçi mat siyah 9mm pistol overlay/model görünümü eklendi.
- Slide, frame, kabza, trigger guard, tetik, namlu, nişangah, rear serration ve kabza doku detayları eklendi.
- Silah elde daha doğal ve referansa daha yakın durur.
- Ateş ederken recoil animasyonu vardır.
- Muzzle flash görseli güçlendirildi.
- Reload sırasında silah hareket animasyonu vardır.
- Joystick hareketinde silah hafif sway yapar.
- v3.5 sistemleri korunur:
  - 15 mermi şarjör
  - yedek mermi
  - boş tetik sesi
  - reload sırasında ateş engeli
  - headshot bonus
  - kill coin
  - horde AI
  - performans cleanup
  - gerçek Three.js CDN

ZIP:
ZombieRush3D_Android_Project_v3_6_REAL_PISTOL_VISUAL_FIX.zip

Artifact:
ZombieRush3D-v3-6-REAL-PISTOL-VISUAL-FIX-debug-apk
